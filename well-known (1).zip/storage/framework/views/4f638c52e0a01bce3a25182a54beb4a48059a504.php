<?php $__env->startSection('description'); ?>
This is Personal Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
Botintel
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
<!-- // being slider -->
<div id="hero-banner" class="banner-inner">
  <div class="jumbotron">
  <div class="container">
    <div class="slide-text wow fadeInUp" >
    <h6>Your</h6>
    <h2>Tasks</h2>
</div>
  </div>
</div>
</div>
<!-- // end slider -->
<section id="pages" class="task-pages">
  <div class="container form-bg">
   <?php if(session()->has('message')): ?>
<div class="bs-example">
<div class="alert alert-success fade in">
<a href="#" class="close" data-dismiss="alert">&times;</a>
<strong><?php echo e(Session::get('message')); ?></strong>
</div>
</div>
<?php endif; ?>
 <?php if(session()->has('error')): ?>
<div class="bs-example">
<div class="alert alert-danger fade in">
<a href="#" class="close" data-dismiss="alert">&times;</a>
<strong><?php echo e(Session::get('error')); ?></strong>
</div>
</div>
<?php endif; ?>
    <div class="row">
     <div class="col-md-12">
        <h2 class="page-heading">TASKS</h2>
     </div>
    </div> 
    <form action="<?php echo e(url('tasks/submit')); ?>"  method="POST" >
      <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
    <div class="row ">
      <div class="task-one" id="task_add">
       <div class="col-md-12">
        <div class="col-md-4">
          <div class="form-group">
            <label >Release</label>
            <select name="release[]" class="form-control">
              <option value="">Please select one</option>
              <?php $__currentLoopData = $releases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $release): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($release->id); ?>"><?php echo e($release->release_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
        <div class="col-md-4">
           <!-- // being form name -->
                    <div class="form-group">
                      <label for="">Size</label>
            <select name="size[]" class="form-control" >
             <option value="">Please select one</option>
             <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($size->id); ?>"><?php echo e($size->size_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </div>
                   <!-- // end form name -->
        </div>
        <div class="col-md-4">
           <!-- // being form name -->
                    <div class="form-group">
                      <label for="">Profile</label>
              <select name="profile[]" class="form-control" id="">
              <option value="">Please select one</option>
              <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($profile->id); ?>"><?php echo e($profile->profile_name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
              </div>
                   <!-- // end form name -->
        </div>
       </div>
    </div>
    </div>
<div class="row">
       <div class="col-md-12">
          <div class="form-group btn-row tasks-btn">
             <button type="button" onclick="Addrow()" class="btn btn-default btn-circle btn-lg" data-toggle="tooltip" data-placement="right" ><i class="glyphicon glyphicon-plus"></i></button>
        <button class="btn btn-primary hvr-sweep-to-top" type="submit">Submit</button>
       <!--  <button class="btn btn-default hvr-sweep-to-left" type="submit">Submit All</button> -->
      </div>
       </div>
     </div>
    
</form>
   </div>

  
</section>
<script type="text/javascript">

    function Addrow() {
      var token = $('#token').val();
 $.ajax({
            type: 'post',
            data: {'_token':token,},
            url: 'tasks/getData',
            dataType: 'json',
            success: function(res){
              if(res){
            $("#task_add").append(res); 
              }
            },
            error: function(res){
                $('#message').html("<div class='alert alert-danger fade in'><a href='#' class='close' data-dismiss='alert'>&times;</a><strong>Error ! Records Not Found</strong></div>");
            }
        });


    
   }

  function delgRow(objx){
    $(objx).parent('div').parent('div').remove(); 
  }


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>