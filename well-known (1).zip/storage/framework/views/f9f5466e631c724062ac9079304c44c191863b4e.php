<!-- First, extends to the CRUDBooster Layout -->

<?php $__env->startSection('content'); ?>
  <!-- Your html goes here -->
  <div class='panel panel-default'>


    <div class='panel-heading'><strong><i class="fa fa-dollar"></i> Import File</strong></div>


    <div class='panel-body'>
	<form action="<?php echo e(url('admin/successorders/submitimport')); ?>" enctype="multipart/form-data" method="post" >
	<?php echo csrf_field(); ?>
		<?php if(session()->has('message')): ?>
		<div class="bs-example">
		<div class="alert alert-success fade in">
		<a href="#" class="close" data-dismiss="alert">&times;</a>
		<?php echo e(session()->get('message')); ?>

		</div>
		</div>

		<?php endif; ?> 
		<?php if(session()->has('error')): ?>
		<div class="bs-example">
		<div class="alert alert-danger fade in">
		<a href="#" class="close" data-dismiss="alert">&times;</a>
		<?php echo e(session()->get('error')); ?>

		</div>
		</div>
		<?php endif; ?> 
      <div class="box-body" id="parent-form-area">
     <div class="col-md-6"> 
	 <div class="form-group">
                        <label>File XLS </label>
						
                        <input type="file" name="xlsfile"   class="form-control" required="">	
                        <div class="help-block">File type supported only : XLS</div>
                    </div>
     </div>
        </div>
		<div class="box-footer">
                    <div class="pull-right">
                        <a href="<?php echo e(url('/admin/successful_orders')); ?>" class="btn btn-default">Cancel</a>
                        <input type="submit" class="btn btn-primary" name="submit" value="Upload">
                    </div>
                </div>
        <!-- etc .... -->
        
      </form>
    </div>

  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('crudbooster::admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>