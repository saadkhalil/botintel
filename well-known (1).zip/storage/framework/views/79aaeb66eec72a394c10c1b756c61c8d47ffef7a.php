<?php $__env->startSection('description'); ?>
This is Personal Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
Botintel
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
<!-- // being slider -->
<!-- // being slider -->
<div id="hero-banner" class="banner-inner">
  <div class="jumbotron">
  <div class="container">
    <div class="slide-text wow fadeInUp" >
      <?php if($pagedetails): ?>  
    <h6><?php echo e($Title[0]); ?></h6>
    <h2><?php echo e($Title[1]); ?></h2>
     <h6><?php echo e($Title[2]); ?></h6>
     <?php else: ?>
      <h2>No Page Found</h2>
     <?php endif; ?>
</div>
  </div>
</div>
</div>
<!-- // end slider -->
<section id="pages" class="privacy-pages">
<div class="container">
  <div class="row">
      <div class="col-sm-12">

    <h3><?php echo e($pagedetails->page_name); ?></h3>
 <?php echo $pagedetails->page_content; ?>

  </div>
  </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>