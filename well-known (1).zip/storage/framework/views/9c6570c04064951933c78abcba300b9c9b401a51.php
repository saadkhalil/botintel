<?php $__env->startSection('description'); ?>
This is Personal Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
Botintel
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
<!-- // being slider -->
<div id="hero-banner" class="banner-inner">
  <div class="jumbotron">
  <div class="container">
    <div class="slide-text wow fadeInUp" >
    <h6>UPCOMING</h6>
    <h2>RELEASES</h2>
    <form id="filterform" >
    <div class="btn-row">
       <input type="checkbox" class="btn btn-us btn-default  filter-button" data-filter="us"     value="US" id="us" name="country[]">US
         <input type="checkbox" class="btn btn-default btn-eu  filter-button"  data-filter="eu"    value="EU" id="eu" name="country[]">EU
    </div>
    <div class="btn-row">
      <input type="checkbox" class="btn btn-default btn-child1  filter-button"  data-filter="nike"   value="1" id="nike" name="brand[]">Nike
        <input type="checkbox" class="btn btn-default btn-child2  filter-button" data-filter="adidas" value="2" id="adidas" name="brand[]">Adidas
    </div>
  </form>
</div>
  </div>
</div>
</div>
<!-- // end slider -->
<section id="pages">
  <div class="container release-listing-view">
    <!-- // being row -->
  <div class="row" id="releaseview"  >
     <!--  // being single column -->
<?php $__currentLoopData = $releases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $release): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div  class="col-sm-4 col-md-4 filter releaserecord" >
     <!--  // being thumbnail -->

    <div class="thumbnail">
      <img src="<?php echo e($release->release_image); ?>"  title="<?php echo e($release->release_image); ?>" alt="<?php echo e($release->release_image); ?>">
    
    
    <!--  // being caption -->
      <div class="caption">
           <p>Name: <?php echo e($release->release_name); ?></p>
<p>SKU: <?php echo e($release->release_code); ?></p>
<p>Release Date: <?php echo e(date('d/m/Y | ha', strtotime($release->release_date))); ?> PST
<p>Submission Time: <?php echo e(date('d', strtotime($release->submission_time))); ?>d  <?php echo e(date('h', strtotime($release->submission_time))); ?>h  <?php echo e(date('i', strtotime($release->submission_time))); ?>m   <?php echo e(date('s', strtotime($release->submission_time))); ?>s </p>
       <!-- //being hover -->
<div class="caption-hover">
<p>Description: <?php echo e($release->release_description); ?>,</p>
</div>
<!-- // end hover -->
    </div>
       <!-- // end caption -->
  </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <!-- // end thumbnail -->


</div>
<!-- // end row -->
 <!-- // being row -->
 


  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>