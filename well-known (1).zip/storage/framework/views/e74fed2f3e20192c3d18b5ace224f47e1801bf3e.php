<?php $__env->startPush('head'); ?>
    <style type="text/css">
        .bootstrap-timepicker .dropdown-menu {
            left: 185px !important;
            box-shadow: 0px 0px 20px #aaaaaa;
        }
    </style>
<?php $__env->stopPush(); ?>