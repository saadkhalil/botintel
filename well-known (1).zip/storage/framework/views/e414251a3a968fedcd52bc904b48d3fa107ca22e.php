</div>
<div style='border-top:1px solid #eeeeee;background:#ffffff;padding:20px;font-size:11px;color:#666'>
    <?php echo e(trans("crudbooster.email_footer")); ?>

</div>
</div>