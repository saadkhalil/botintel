<?php $__env->startPush('bottom'); ?>
    <script src="<?php echo e(asset('vendor/laravel-filemanager/js/lfm.js')); ?>"></script>
<?php $__env->stopPush(); ?>