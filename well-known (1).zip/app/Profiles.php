<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Profiles extends Model
{
    //
     protected $table="profile";
    protected $primaryKey="id";

}
