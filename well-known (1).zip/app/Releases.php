<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Releases extends Model
{
    //

      protected $table="releases";
    protected $primaryKey="id";
}
